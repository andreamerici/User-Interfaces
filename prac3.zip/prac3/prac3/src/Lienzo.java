
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Olesya Dudchuk, Andrea Merici
 */
public class Lienzo extends JPanel {
    
    private Color colorFondo;
    private Color colorPincel;
    private float grosor;
    
    ArrayList<Point2D> pointsArray = new ArrayList<>();
    
    /**
     * Constructor method
     */
    public Lienzo(){
        colorFondo = Color.WHITE;
        colorPincel = Color.BLACK;
        grosor = 5.0f;
    }
    
    /**
     * This method sets the background and the foreground colours and draws the mouse trail
     * @param g: graphic object used for the drawing
     */
    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        this.setBackground(colorFondo);
        this.setForeground(colorPincel);
         
        int px[] = new int[pointsArray.size()];
        int py[] = new int[pointsArray.size()];
        
        for(int i = 0; i < pointsArray.size(); i++){
            px[i] = (int)pointsArray.get(i).getX();
            py[i] = (int)pointsArray.get(i).getY();  
            g2d.fill(new Ellipse2D.Double(px[i], py[i], grosor, grosor));
        }
            
    }
    
    /**
     * This method adds a new point to the at the list of points reached by the mouse
     * and eventually maintains the size of that list by eliminating the most remote element
     * @param centro: the new point that has to be added 
     */
    public void pinta(Point2D centro){
       pointsArray.add(centro);
       
       if(pointsArray.size() > 5){
           pointsArray.remove(0);
       }   
    }
    
    /**
     * Change the colour of the background
     * @param colorBack: the selected code color for the background
     */
    public void changeColorBack(int colorBack){
        switch (colorBack){
            case 0:
                colorFondo = Color.WHITE;
                break;
            case 1:
                colorFondo = Color.YELLOW;
                break;
            case 2:
                colorFondo = Color.GREEN;
                break;
            case 3:
                colorFondo = Color.PINK;
                break;
        }
           
    }

    /**
     * Change the colour of the mouse trail
     * @param colorFront: the selected code color for the mouse trail
     */
    public void changeColorFront(int colorFront){
       
        switch (colorFront){
            case 0:
                colorPincel = Color.BLACK;
                break;
            case 1:
                colorPincel = Color.GRAY;
                break;
            case 2:
                colorPincel = Color.BLUE;
                break;
            case 3:
                colorPincel = Color.RED;
                break;
        }
           
    }
    
}
